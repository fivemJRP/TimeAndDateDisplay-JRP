<h1 align="center">Hi 👋, I'm LucaNL</h1>
<h3 align="center">I'am a mainly FiveM Developer</h3>

- 📫 How to reach me? Send me a message on here or **LucaNL#2230** on discord.

I myself was always looking for a good working script for a Time And Date Display with real life times, so that the real life time is in your screen.

But I could never really find anything good, and something that actually did it well so that's why I made this **Time And Date Display** Script.

# TimeAndDateDisplay-FiveM

A script that allows you to always show the real life time and real life date on the top right of your screen.

### Features:

> - Real Life Time and Date is in the upper right corner of your screen.
> - A option to show your server name in after the time.
> - A option to show the players his own name under the time.
> - A option to show to players his ingame id under the time.
> - Easy Configure everyting.
> - The Script does not cause lag or reduce server performance because it goes through the HTML and JS.

### Requirements:

> - None

# Download And Install

[**DOWNLOAD**](https://github.com/LucaNL/TimeAndDateDisplay-FiveM/archive/refs/heads/main.zip) 

### How to install
1. [**Download**](https://github.com/LucaNL/TimeAndDateDisplay-FiveM/archive/refs/heads/main.zip) the recource.
2. Change the config.lua to what you like.
4. Add this to your server.cfg:
```
ensure TimeAndDateDisplay-FiveM
```
5. Restart Server.

# Changelog

**Changelog v2.0.0**
```
  - Config better and everything clearer
  - A completely different way of displaying the time used to be via lua but that took a lot of performance so it is now done via HTML and JS. (thanks jsqr#0001)
  - Version checker update
```
