Config = {}

Config.ShowServerName = true -- Set true to show the given Config.ServerName below

Config.ServerName = "JRP" -- Shows this name if Config.ShowServerName = true

Config.ShowPlayerName = false -- Set true to show to player name

Config.ShowPlayerID = false -- Set True to show to player id

-- One of the following config things below must be set to true

Config.ShowDateAndTime = true -- Set true to show Date and Time

Config.ShowOnlyDate = false -- Set true to show only the Date

Config.ShowOnlyTime = false -- Set true to show only the Time

-- One of the following config things below must be set to true

Config.DayMonthYear = false -- Set true to have DD-MM-YYYY

Config.MonthDayYear = true -- Set true to have MM-DD-YYYY

Config.YearMonthDay = false -- Set true to have YYYY-MM-DD

Config.YearDayMonth = false -- Set true to have YYYY-DD-MM

Config.TimezoneOffset = 0 -- set this to the offset you need. 
--example -1 will make the time 1 hour earlier and 1 will make the time one hour later.

-- Validation function to ensure only one date/time option is true
function Config.Validate()
    local dateOptions = {Config.DayMonthYear, Config.MonthDayYear, Config.YearMonthDay, Config.YearDayMonth}
    local trueCount = 0
    for _, v in ipairs(dateOptions) do
        if v then trueCount = trueCount + 1 end
    end
    if trueCount ~= 1 then
        print("[TimeAndDateDisplay] Warning: Exactly one date format must be true. Defaulting to MonthDayYear.")
        Config.DayMonthYear = false
        Config.MonthDayYear = true
        Config.YearMonthDay = false
        Config.YearDayMonth = false
    end

    local timeOptions = {Config.ShowDateAndTime, Config.ShowOnlyDate, Config.ShowOnlyTime}
    trueCount = 0
    for _, v in ipairs(timeOptions) do
        if v then trueCount = trueCount + 1 end
    end
    if trueCount ~= 1 then
        print("[TimeAndDateDisplay] Warning: Exactly one time display option must be true. Defaulting to ShowDateAndTime.")
        Config.ShowDateAndTime = true
        Config.ShowOnlyDate = false
        Config.ShowOnlyTime = false
    end
end

-- Cache config values on load
Config.Cached = {
    ShowServerName = Config.ShowServerName,
    ServerName = Config.ServerName,
    ShowPlayerName = Config.ShowPlayerName,
    ShowPlayerID = Config.ShowPlayerID,
    ShowDateAndTime = Config.ShowDateAndTime,
    ShowOnlyDate = Config.ShowOnlyDate,
    ShowOnlyTime = Config.ShowOnlyTime,
    DayMonthYear = Config.DayMonthYear,
    MonthDayYear = Config.MonthDayYear,
    YearMonthDay = Config.YearMonthDay,
    YearDayMonth = Config.YearDayMonth,
    TimezoneOffset = Config.TimezoneOffset
}

Config.Validate()
